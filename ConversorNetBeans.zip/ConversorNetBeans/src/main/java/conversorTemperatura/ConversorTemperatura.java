/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conversorTemperatura;

/**
 *
 * @author Ernesto
 */
public class ConversorTemperatura {
    public double convertirCelsius_Kelvin(double temperatura) {
	double total = 273.15+temperatura;
        return total;
        }	
    public double convertirCelsius_Fahrenheit(double temperatura) {
	double total = (double)temperatura*9/5+32;
        return total;
        }	
	public double convertirKelvin_Fahrenheit(double temperatura) {
	double total = (double) (temperatura*9/5-459.67); 
        return total;
        }	
    public double convertirKelvin_Celsius(double temperatura) {
	double total = (double)(temperatura-273.15);
        return total;
        }	
    public double convertirFahrenheit_Kelvin(double temperatura) {
	double total = (double) ((temperatura+459.67)*5/9);
        return total;
		
	}
    public double convertirFahrenheit_Celcius(double temperatura) {
	double total = (double)(temperatura-32)*5/9;
        return total;
        }	
}

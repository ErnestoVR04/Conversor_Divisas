/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conversorTemperatura;

/**
 *
 * @author Ernesto
 */
public class FunctionTemp {
    public double conversorTemperatura(double temperatura, String factor){
        ConversorTemperatura ct = new ConversorTemperatura();
        double total = 0;
        switch(factor){
            case "CelciusFahrenhait" -> total = ct.convertirCelsius_Fahrenheit(temperatura);
            case "CelciusKelvin" -> total = ct.convertirCelsius_Kelvin(temperatura);
            case "FahrenhaitCelcius" -> total = ct.convertirFahrenheit_Celcius(temperatura);
            case "FahrenhaitKelvin" -> total = ct.convertirFahrenheit_Kelvin(temperatura);
            case "KelvinCelcius" -> total = ct.convertirKelvin_Celsius(temperatura);
            case "KelvinFahrenhait" -> total = ct.convertirKelvin_Fahrenheit(temperatura);
        }
        return total;
    }
}

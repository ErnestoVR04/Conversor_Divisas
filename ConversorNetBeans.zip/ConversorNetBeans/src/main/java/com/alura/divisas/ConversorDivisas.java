/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alura.divisas;
    
import com.alura.views.Divisas;

/**
 *
 * @author Ernesto
 */
public class ConversorDivisas {
        
        public double convertirPesos_Dolares(double importe) {
		double total = (importe/17.3286);
                return total;
	}
	public double convertirPesos_Euros(double importe) {
		double total = (importe/18.98);
                return total;
	}
	public double convertirPesos_Libras(double importe) {
		double total = (importe/22.03);
                return total;
	}
	public double convertirPesos_Yen(double importe) {
		double total = (importe/0.12);
                return total;
	}
	public double convertirPesos_Won(double importe) {
		double total = (importe/0.013);
                return total;
	}
	
	//Divisa a pesos
	public double convertirDolares_Pesos(double importe) {
		double total=(float) (17.3286*importe);
                return total;
	}
	public double convertirEuros_Pesos(double importe) {
		double total=(float) (18.98*importe);
                return total;
	}
	public double convertirLibras_Pesos(double importe) {
		double total=(float) (22.03*importe);
                return total;
	}
	public double convertirYen_Pesos(double importe) {
		double total=(float) (0.12*importe);
                return total;
	}
	public double convertirWon_Pesos(double importe) {
                double total=(float) (0.013*importe);
                return total;
	}	
}

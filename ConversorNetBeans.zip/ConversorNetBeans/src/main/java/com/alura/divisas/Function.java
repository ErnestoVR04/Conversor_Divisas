/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alura.divisas;

/**
 *
 * @author Ernesto
 */
public class Function {
    
    ConversorDivisas conversorDivisas = new ConversorDivisas();
    double total = 0;
    public double convertirDivisas(double importe, String factor){
        switch(factor) {
            case "Peso Dolar" -> total = conversorDivisas.convertirPesos_Dolares(importe);
            case "Peso Euro" -> total = conversorDivisas.convertirPesos_Euros(importe);
            case "Peso Libra" -> total = conversorDivisas.convertirPesos_Libras(importe);
            case "Peso Yen" -> total = conversorDivisas.convertirPesos_Yen(importe);
            case "Peso Won Coreano" -> total = conversorDivisas.convertirPesos_Won(importe);
            case "Dólar Peso" -> total = conversorDivisas.convertirDolares_Pesos(importe);
            case "Euro Peso" -> total = conversorDivisas.convertirEuros_Pesos(importe);
            case "Libra Peso" -> total = conversorDivisas.convertirLibras_Pesos(importe);
            case "Yen Peso" -> total = conversorDivisas.convertirYen_Pesos(importe);
            case "Won Coreano Peso" -> total = conversorDivisas.convertirWon_Pesos(importe);
        }      
        return total;
    }
}
